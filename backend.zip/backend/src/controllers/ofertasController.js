const ofertasService = require('../services/ofertasService');

// obtiene ofertas
const getOfertas = async (req, res, next) => {
  try {
    const { buscar } = req.query;

    const ofertas = await ofertasService.buscarOfertas(buscar);

    res.json(ofertas);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getOfertas
};